-- ══════════════════════════════════════════════════
-- Arin License System — Database Setup
-- รัน SQL นี้ใน phpMyAdmin หรือ MySQL CLI
-- ══════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS licenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    license_key VARCHAR(64) UNIQUE NOT NULL,
    customer_name VARCHAR(100) DEFAULT '',
    customer_email VARCHAR(100) DEFAULT '',
    product VARCHAR(50) NOT NULL COMMENT 'arin-meta-bot, arin-grok-bot, etc.',
    plan_type ENUM('daily','weekly','monthly') DEFAULT 'monthly',
    max_devices INT DEFAULT 1,
    expires_at DATETIME NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_key_product (license_key, product),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS device_bindings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    license_id INT NOT NULL,
    machine_id VARCHAR(128) NOT NULL,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_license_device (license_id, machine_id),
    FOREIGN KEY (license_id) REFERENCES licenses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS usage_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    license_id INT,
    action VARCHAR(50) NOT NULL,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_license_action (license_id, action),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ══════════════════════════════════════════════════
-- ตัวอย่าง: สร้าง License Key ทดสอบ (30 วัน, 2 เครื่อง)
-- ══════════════════════════════════════════════════
INSERT INTO licenses (license_key, customer_name, product, plan_type, max_devices, expires_at)
VALUES ('TEST-ARIN-2024-DEMO', 'Admin Test', 'arin-meta-bot', 'monthly', 2, DATE_ADD(NOW(), INTERVAL 30 DAY));
